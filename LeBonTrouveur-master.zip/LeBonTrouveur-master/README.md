# LeBonTrouveur

Bonjour, bienvenue sur la page GitHub d'un projet tutoré d'étudiant en ingénierie consistant à utiliser du webscraping pour récupérer des données sur le site le bon coin.